from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=40)
    enrollment = serializers.CharField(max_length=40)
    phone = serializers.CharField(max_length=15)
    email = serializers.EmailField()


    def create(self, validated_data):
        print("create method called ")
        return Student.objects.create(**validated_data)

    def update(self, student, validated_data):
        newStudent = Student(**validated_data)
        newStudent.id = student.id;
        newStudent.save()
        return newStudent


