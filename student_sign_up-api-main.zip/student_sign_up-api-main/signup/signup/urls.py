from django.contrib import admin
from django.urls import path
from student.views import studentListView, studentDetailView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/students', studentListView),
    path('api/students/<int:pk>', studentDetailView),

]
